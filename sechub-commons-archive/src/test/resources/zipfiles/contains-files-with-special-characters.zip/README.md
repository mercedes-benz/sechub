## About
This zip folder contains file(s) with special characters

